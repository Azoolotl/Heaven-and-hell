# Heaven & Hell ability sound assignments

All seven audio files supplied for this project were converted to mono 44.1 kHz OGG Vorbis and placed in `src/main/resources/assets/heavenhell/sounds/`.

| In-game sound event | Source upload | Usage |
|---|---|---|
| `holy_burst` | `holy_burst.mp3` | Holy Burst activation |
| `divine_judgement` | `divine-judgement.mp3` | Divine Judgement targeting/cast cue |
| `heavens_wrath` | `Heaven's-wrath.mp3` | Heaven's Wrath zone activation |
| `infernal_blast` | `infernal-blast.mp3` | Infernal Blast activation |
| `hellfire_chains_hit` | `hellfire-chains-spectral-chain-hit.mp3` | Successful Hellfire Chains hit |
| `hellfire_chains_miss` | `hellfire-chains-miss.mp3` | Failed Hellfire Chains target acquisition |
| `infernal_cataclysm` | `infernal-catacylasm.mp3` | Infernal Cataclysm zone activation |

The two Hellfire Chains cues are intentionally separate. These effects are positional sounds played by the logical server, so nearby clients hear the same event at its world location. Sound assets are non-looping unless later changed in `sounds.json`.
