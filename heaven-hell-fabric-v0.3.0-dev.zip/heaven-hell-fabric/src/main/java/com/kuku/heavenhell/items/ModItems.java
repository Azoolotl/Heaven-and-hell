package com.kuku.heavenhell.items;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.data.Race;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

import java.util.function.Function;

/** Registered craftable cores and one-time purification artifacts. */
public final class ModItems {
    public static final Item CELESTIAL_CORE = register("celestial_core", Item::new,
            new Item.Properties().stacksTo(16).rarity(Rarity.RARE));
    public static final Item INFERNAL_CORE = register("infernal_core", Item::new,
            new Item.Properties().stacksTo(16).rarity(Rarity.RARE));
    public static final Item DIVINE_PURIFICATION = register("divine_purification",
            properties -> new PurificationItem(properties, Race.ANGEL),
            new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
    public static final Item INFERNAL_PURIFICATION = register("infernal_purification",
            properties -> new PurificationItem(properties, Race.DEMON),
            new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    private ModItems() {}

    private static <T extends Item> T register(String path, Function<Item.Properties, T> factory,
                                                Item.Properties properties) {
        Identifier id = Identifier.fromNamespaceAndPath(HeavenHell.MOD_ID, path);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        T item = factory.apply(properties.setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            entries.accept(CELESTIAL_CORE);
            entries.accept(INFERNAL_CORE);
            entries.accept(DIVINE_PURIFICATION);
            entries.accept(INFERNAL_PURIFICATION);
        });
        HeavenHell.LOGGER.info("Registered Heaven & Hell purification artifacts and cores");
    }
}
