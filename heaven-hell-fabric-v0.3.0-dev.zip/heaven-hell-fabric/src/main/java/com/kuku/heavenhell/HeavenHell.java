package com.kuku.heavenhell;

import com.kuku.heavenhell.command.HeavenHellCommands;
import com.kuku.heavenhell.config.HeavenHellConfig;
import com.kuku.heavenhell.data.PlayerDataStore;
import com.kuku.heavenhell.gameplay.PassiveAbilityService;
import com.kuku.heavenhell.gameplay.ActiveAbilityService;
import com.kuku.heavenhell.audio.AbilitySounds;
import com.kuku.heavenhell.network.AbilityNetworking;
import com.kuku.heavenhell.network.StatusSync;
import com.kuku.heavenhell.items.ModItems;
import com.kuku.heavenhell.items.PurificationItem;
import com.kuku.heavenhell.gameplay.ProgressionEvents;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.file.Path;

/** Common/server entrypoint. Gameplay authority belongs on the logical server. */
public final class HeavenHell implements ModInitializer {
    public static final String MOD_ID = "heavenhell";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final PlayerDataStore DATA = new PlayerDataStore();
    public static HeavenHellConfig CONFIG = new HeavenHellConfig();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("heavenhell.json");

    @Override
    public void onInitialize() {
        CONFIG = HeavenHellConfig.load(CONFIG_PATH);
        AbilitySounds.initialize();
        ModItems.initialize();
        AbilityNetworking.register();
        ActiveAbilityService.register();
        HeavenHellCommands.register();
        ProgressionEvents.register();
        PassiveAbilityService.register();
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            DATA.load(server);
            LOGGER.info("Heaven & Hell loaded {} player records", DATA.all().size());
        });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            DATA.get(handler.player.getUUID());
            StatusSync.syncAllTo(handler.player);
            StatusSync.broadcast(handler.player);
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            StatusSync.removeFromClients(newPlayer.getServer(), oldPlayer.getId());
            StatusSync.broadcast(newPlayer);
        });
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) ->
                StatusSync.broadcast(player));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ActiveAbilityService.onDisconnect(handler.player.getUUID());
            PurificationItem.clearPending(handler.player.getUUID());
            StatusSync.removeFromClients(server, handler.player.getId());
            DATA.save();
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> DATA.save());
        LOGGER.info("Heaven & Hell foundation initialized");
    }

    public static void reloadConfig() { CONFIG = HeavenHellConfig.load(CONFIG_PATH); }
}
