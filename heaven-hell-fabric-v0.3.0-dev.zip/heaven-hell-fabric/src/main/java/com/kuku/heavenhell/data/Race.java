package com.kuku.heavenhell.data;

public enum Race {
    HUMAN, ANGEL, DEMON;
    public static Race parse(String value) {
        return switch (value.toLowerCase()) {
            case "human" -> HUMAN;
            case "angel" -> ANGEL;
            case "demon" -> DEMON;
            default -> throw new IllegalArgumentException("Race must be human, angel, or demon");
        };
    }
}
