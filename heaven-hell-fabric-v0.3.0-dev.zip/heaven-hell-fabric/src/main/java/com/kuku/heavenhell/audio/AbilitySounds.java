package com.kuku.heavenhell.audio;

import com.kuku.heavenhell.HeavenHell;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.core.Registry;

/** Registered custom ability sound events. Audio is played positionally by the server. */
public final class AbilitySounds {
    public static final SoundEvent HOLY_BURST = register("holy_burst");
    public static final SoundEvent DIVINE_JUDGEMENT = register("divine_judgement");
    public static final SoundEvent HEAVENS_WRATH = register("heavens_wrath");
    public static final SoundEvent INFERNAL_BLAST = register("infernal_blast");
    public static final SoundEvent HELLFIRE_CHAINS_HIT = register("hellfire_chains_hit");
    public static final SoundEvent HELLFIRE_CHAINS_MISS = register("hellfire_chains_miss");
    public static final SoundEvent INFERNAL_CATACLYSM = register("infernal_cataclysm");

    private AbilitySounds() {}

    private static SoundEvent register(String path) {
        Identifier id = Identifier.fromNamespaceAndPath(HeavenHell.MOD_ID, path);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    public static void initialize() {
        // Referencing this method forces class initialization before sound playback.
    }
}
