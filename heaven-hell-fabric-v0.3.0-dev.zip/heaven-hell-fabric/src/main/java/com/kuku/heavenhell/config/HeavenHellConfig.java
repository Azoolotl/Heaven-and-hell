package com.kuku.heavenhell.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Server-owned configuration. Invalid values are clamped to safe ranges on load. */
public final class HeavenHellConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public int karmaHelp = 10, karmaGift = 3, karmaHostileKill = 1, karmaPassiveKill = -3;
    public int karmaPlayerKill = -10, karmaBetrayal = -15, karmaHigherKarmaKillBonus = -15;
    public int angelThreshold = 20, archangelThreshold = 50, seraphimThreshold = 80;
    public int demonThreshold = -20, archdemonThreshold = -50, demonLordThreshold = -80;

    public boolean overworldDemonWeakness = true, netherAngelWeakness = true;
    public boolean purificationEnabled = true;
    public boolean friendlyFire = false, actionBarNotifications = true;

    /** Same killer/victim pair can only change the killer's karma once per this many seconds. */
    public int samePlayerKillCooldownSeconds = 3600;
    /** Maximum positive karma earned from hostile mob kills per UTC day. */
    public int mobKillDailyKarmaCap = 20;
    /** Maximum positive karma earned from gifts per donor per UTC day. */
    public int transferDailyCap = 12;
    /** Repeated gifts to the same recipient diminish and stop after this many rewarded transfers. */
    public int rewardedGiftTransfersPerRecipientPerDay = 2;
    /** Repeat help events for the same recipient are limited to one per donor/recipient interval. */
    public int helpRewardCooldownSeconds = 600;
    public int purificationConfirmSeconds = 10;

    public boolean angelBlessingEnabled = true;
    public float angelBlessingHeal = 1.0f;
    public int angelBlessingIntervalSeconds = 10;
    public boolean archangelResistanceEnabled = true;
    public boolean seraphimPoisonImmunity = true;
    public boolean demonFireResistanceEnabled = true;
    public int demonEmberbornChancePercent = 10;
    public int demonBloodthirstRequiredHits = 5;
    public float demonBloodthirstHeal = 2.0f;
    public int demonBloodthirstCooldownSeconds = 10;
    public int demonLordDreadRadius = 8;
    public int demonLordDreadPulseTicks = 40;
    public int passivePulseTicks = 20;
    public boolean auraParticlesEnabled = true;

    // Active ability tuning. Damage values use Minecraft health points (2 HP = 1 heart).
    public int holyBurstCooldownSeconds = 35, divineJudgementCooldownSeconds = 55, heavensWrathCooldownSeconds = 120;
    public int infernalBlastCooldownSeconds = 35, hellfireChainsCooldownSeconds = 55, infernalCataclysmCooldownSeconds = 120;
    public float holyBurstDamage = 4.0f, holyBurstHeal = 4.0f, holyBurstRadius = 6.0f, holyBurstKnockback = 0.9f;
    public float divineJudgementDamage = 8.0f, divineJudgementRange = 15.0f;
    public int divineJudgementSlownessTicks = 60;
    public float heavensWrathRadius = 12.0f;
    public int heavensWrathDurationSeconds = 8;
    public float infernalBlastDamage = 4.0f, infernalBlastRadius = 6.0f, infernalBlastKnockback = 0.9f;
    public int infernalBlastFireSeconds = 4;
    public float hellfireChainsDamage = 6.0f, hellfireChainsRange = 12.0f, hellfireChainsPullStrength = 1.2f;
    public int hellfireChainsStunTicks = 40;
    public float infernalCataclysmRadius = 12.0f;
    public int infernalCataclysmDurationSeconds = 8;
    public float zoneDamage = 2.0f, zoneAllyHeal = 2.0f, cataclysmEruptionChance = 0.35f;

    public static HeavenHellConfig load(Path path) {
        try {
            Files.createDirectories(path.getParent());
            if (!Files.exists(path)) {
                HeavenHellConfig fresh = new HeavenHellConfig();
                Files.writeString(path, GSON.toJson(fresh));
                return fresh;
            }
            HeavenHellConfig loaded = GSON.fromJson(Files.readString(path), HeavenHellConfig.class);
            if (loaded == null) loaded = new HeavenHellConfig();
            loaded.sanitize();
            return loaded;
        } catch (IOException | RuntimeException e) {
            return new HeavenHellConfig();
        }
    }

    public void sanitize() {
        karmaHelp = clamp(karmaHelp, -100, 100);
        karmaGift = clamp(karmaGift, 0, 20);
        karmaHostileKill = clamp(karmaHostileKill, 0, 5);
        karmaPassiveKill = clamp(karmaPassiveKill, -20, 0);
        karmaPlayerKill = clamp(karmaPlayerKill, -50, 0);
        karmaBetrayal = clamp(karmaBetrayal, -50, 0);
        karmaHigherKarmaKillBonus = clamp(karmaHigherKarmaKillBonus, -50, 0);

        angelThreshold = clamp(angelThreshold, 1, 100);
        archangelThreshold = clamp(archangelThreshold, angelThreshold, 100);
        seraphimThreshold = clamp(seraphimThreshold, archangelThreshold, 100);
        demonThreshold = clamp(demonThreshold, -100, -1);
        archdemonThreshold = clamp(archdemonThreshold, -100, demonThreshold);
        demonLordThreshold = clamp(demonLordThreshold, -100, archdemonThreshold);

        samePlayerKillCooldownSeconds = clamp(samePlayerKillCooldownSeconds, 60, 604800);
        mobKillDailyKarmaCap = clamp(mobKillDailyKarmaCap, 0, 100);
        transferDailyCap = clamp(transferDailyCap, 0, 100);
        rewardedGiftTransfersPerRecipientPerDay = clamp(rewardedGiftTransfersPerRecipientPerDay, 0, 20);
        helpRewardCooldownSeconds = clamp(helpRewardCooldownSeconds, 60, 86400);
        purificationConfirmSeconds = clamp(purificationConfirmSeconds, 3, 30);
        angelBlessingHeal = clamp(angelBlessingHeal, 0.0f, 10.0f);
        angelBlessingIntervalSeconds = clamp(angelBlessingIntervalSeconds, 1, 3600);
        demonEmberbornChancePercent = clamp(demonEmberbornChancePercent, 0, 100);
        demonBloodthirstRequiredHits = clamp(demonBloodthirstRequiredHits, 1, 100);
        demonBloodthirstHeal = clamp(demonBloodthirstHeal, 0.0f, 10.0f);
        demonBloodthirstCooldownSeconds = clamp(demonBloodthirstCooldownSeconds, 1, 3600);
        demonLordDreadRadius = clamp(demonLordDreadRadius, 1, 24);
        demonLordDreadPulseTicks = clamp(demonLordDreadPulseTicks, 10, 200);
        passivePulseTicks = clamp(passivePulseTicks, 10, 100);
        holyBurstCooldownSeconds = clamp(holyBurstCooldownSeconds, 1, 3600);
        divineJudgementCooldownSeconds = clamp(divineJudgementCooldownSeconds, 1, 3600);
        heavensWrathCooldownSeconds = clamp(heavensWrathCooldownSeconds, 1, 3600);
        infernalBlastCooldownSeconds = clamp(infernalBlastCooldownSeconds, 1, 3600);
        hellfireChainsCooldownSeconds = clamp(hellfireChainsCooldownSeconds, 1, 3600);
        infernalCataclysmCooldownSeconds = clamp(infernalCataclysmCooldownSeconds, 1, 3600);
        holyBurstDamage = clamp(holyBurstDamage, 0, 40); holyBurstHeal = clamp(holyBurstHeal, 0, 40);
        holyBurstRadius = clamp(holyBurstRadius, 1, 24); holyBurstKnockback = clamp(holyBurstKnockback, 0, 3);
        divineJudgementDamage = clamp(divineJudgementDamage, 0, 40); divineJudgementRange = clamp(divineJudgementRange, 1, 32);
        divineJudgementSlownessTicks = clamp(divineJudgementSlownessTicks, 1, 200);
        heavensWrathRadius = clamp(heavensWrathRadius, 1, 32); heavensWrathDurationSeconds = clamp(heavensWrathDurationSeconds, 1, 30);
        infernalBlastDamage = clamp(infernalBlastDamage, 0, 40); infernalBlastRadius = clamp(infernalBlastRadius, 1, 24);
        infernalBlastKnockback = clamp(infernalBlastKnockback, 0, 3); infernalBlastFireSeconds = clamp(infernalBlastFireSeconds, 0, 20);
        hellfireChainsDamage = clamp(hellfireChainsDamage, 0, 40); hellfireChainsRange = clamp(hellfireChainsRange, 1, 24);
        hellfireChainsPullStrength = clamp(hellfireChainsPullStrength, 0, 3); hellfireChainsStunTicks = clamp(hellfireChainsStunTicks, 1, 200);
        infernalCataclysmRadius = clamp(infernalCataclysmRadius, 1, 32); infernalCataclysmDurationSeconds = clamp(infernalCataclysmDurationSeconds, 1, 30);
        zoneDamage = clamp(zoneDamage, 0, 20); zoneAllyHeal = clamp(zoneAllyHeal, 0, 20);
        cataclysmEruptionChance = clamp(cataclysmEruptionChance, 0, 1);
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private static float clamp(float value, float min, float max) {
        if (!Float.isFinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }

    public void save(Path path) {
        sanitize();
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, GSON.toJson(this));
        } catch (IOException e) {
            throw new IllegalStateException("Could not save Heaven & Hell config", e);
        }
    }
}
