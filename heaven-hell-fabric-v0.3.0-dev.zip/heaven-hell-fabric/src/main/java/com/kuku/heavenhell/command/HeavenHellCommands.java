package com.kuku.heavenhell.command;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.api.KarmaService;
import com.kuku.heavenhell.data.*;
import com.kuku.heavenhell.gameplay.ActiveAbilityService;
import com.kuku.heavenhell.network.StatusSync;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class HeavenHellCommands {
    private HeavenHellCommands() {}
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("karma")
                .executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    showKarma(ctx.getSource(), p); return 1;
                })
                .then(Commands.literal("get").requires(s -> s.hasPermission(2))
                    .then(Commands.argument("player", EntityArgument.player()).executes(ctx -> {
                        showKarma(ctx.getSource(), EntityArgument.getPlayer(ctx, "player")); return 1;
                    })))
                .then(Commands.literal("set").requires(s -> s.hasPermission(2))
                    .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(-100, 100)).executes(ctx -> {
                        ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                        PlayerData d = HeavenHell.DATA.get(p.getUUID());
                        int old = d.karma;
                        Race oldRace = d.race;
                        Rank oldRank = d.rank();
                        d.setKarma(IntegerArgumentType.getInteger(ctx, "amount"));
                        KarmaService.notifyProgression(p, oldRace, oldRank, d);
                        HeavenHell.DATA.save();
                        ctx.getSource().sendSuccess(() -> Component.literal("Set " + p.getName().getString() + " karma from " + old + " to " + d.karma + "."), true);
                        return 1;
                    }))))
                .then(Commands.literal("add").requires(s -> s.hasPermission(2))
                    .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(-200, 200)).executes(ctx -> {
                        ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                        PlayerData d = HeavenHell.DATA.get(p.getUUID());
                        Race oldRace = d.race; Rank oldRank = d.rank();
                        d.addKarma(IntegerArgumentType.getInteger(ctx, "amount"));
                        KarmaService.notifyProgression(p, oldRace, oldRank, d);
                        HeavenHell.DATA.save();
                        ctx.getSource().sendSuccess(() -> Component.literal("Updated " + p.getName().getString() + " karma: " + d.karma + "."), true); return 1;
                    }))))
                .then(Commands.literal("remove").requires(s -> s.hasPermission(2))
                    .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(0, 200)).executes(ctx -> {
                        ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                        PlayerData d = HeavenHell.DATA.get(p.getUUID());
                        Race oldRace = d.race; Rank oldRank = d.rank();
                        d.addKarma(-IntegerArgumentType.getInteger(ctx, "amount"));
                        KarmaService.notifyProgression(p, oldRace, oldRank, d);
                        HeavenHell.DATA.save();
                        ctx.getSource().sendSuccess(() -> Component.literal("Updated " + p.getName().getString() + " karma: " + d.karma + "."), true); return 1;
                    })))));

            dispatcher.register(Commands.literal("race")
                .then(Commands.literal("info")
                    .then(Commands.argument("player", EntityArgument.player()).executes(ctx -> {
                        ServerPlayer p = EntityArgument.getPlayer(ctx, "player"); PlayerData d = HeavenHell.DATA.get(p.getUUID());
                        ctx.getSource().sendSuccess(() -> Component.literal(p.getName().getString() + " — Race: " + d.race + " | Rank: " + d.rank().display() + " | Karma: " + d.karma + (d.isPowerless() ? " | POWERLESS" : "")), false); return 1;
                    })))
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2))
                    .then(Commands.argument("player", EntityArgument.player()).executes(ctx -> {
                        ServerPlayer p = EntityArgument.getPlayer(ctx, "player"); HeavenHell.DATA.get(p.getUUID()).purify(); ActiveAbilityService.onRaceReset(p.getUUID()); HeavenHell.DATA.save(); StatusSync.broadcast(p);
                        ctx.getSource().sendSuccess(() -> Component.literal("Reset race and karma for " + p.getName().getString() + "."), true); return 1;
                    })))
                .then(Commands.literal("set").requires(s -> s.hasPermission(2))
                    .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("race", com.mojang.brigadier.arguments.StringArgumentType.word()).suggests((c,b) -> net.minecraft.commands.SharedSuggestionProvider.suggest(new String[]{"human","angel","demon"}, b)).executes(ctx -> {
                        ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                        Race race;
                        try { race = Race.parse(com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "race")); }
                        catch (IllegalArgumentException e) { ctx.getSource().sendFailure(Component.literal(e.getMessage())); return 0; }
                        HeavenHell.DATA.get(p.getUUID()).setRace(race); ActiveAbilityService.onRaceReset(p.getUUID()); HeavenHell.DATA.save(); StatusSync.broadcast(p);
                        ctx.getSource().sendSuccess(() -> Component.literal("Set " + p.getName().getString() + " race to " + race + "."), true); return 1;
                    })))));

            dispatcher.register(Commands.literal("heavenhell")
                .then(Commands.literal("status").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    showKarma(ctx.getSource(), p);
                    return 1;
                }))
                .then(Commands.literal("reload").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    HeavenHell.reloadConfig();
                    if (ctx.getSource().getServer() != null) {
                        for (ServerPlayer online : ctx.getSource().getServer().getPlayerList().getPlayers()) {
                            StatusSync.broadcast(online);
                        }
                    }
                    ctx.getSource().sendSuccess(() -> Component.literal("Heaven & Hell configuration reloaded."), true);
                    return 1;
                })));
        });
    }
    private static void showKarma(net.minecraft.commands.CommandSourceStack source, ServerPlayer p) {
        PlayerData d = HeavenHell.DATA.get(p.getUUID());
        source.sendSuccess(() -> Component.literal(p.getName().getString() + " — " + d.karma + "/100 karma | " + d.race + " | " + d.rank().display() + (d.isPowerless() ? " (Powerless)" : "")), false);
    }
}
