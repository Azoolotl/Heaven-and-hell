package com.kuku.heavenhell.network;

import com.kuku.heavenhell.HeavenHell;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Minimal client request. The server derives identity, rank, target, and cooldown itself. */
public record ActivateAbilityPayload(int slot) implements CustomPacketPayload {
    public static final Type<ActivateAbilityPayload> TYPE = new Type<>(
            Identifier.fromNamespaceAndPath(HeavenHell.MOD_ID, "activate_ability"));
    public static final StreamCodec<RegistryFriendlyByteBuf, ActivateAbilityPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, ActivateAbilityPayload::slot, ActivateAbilityPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
