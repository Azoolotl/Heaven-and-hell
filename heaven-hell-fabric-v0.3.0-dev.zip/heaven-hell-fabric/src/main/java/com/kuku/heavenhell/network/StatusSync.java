package com.kuku.heavenhell.network;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.data.PlayerData;
import com.kuku.heavenhell.gameplay.ActiveAbilityService;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;

/** Sends authoritative, small player-status snapshots to online clients. */
public final class StatusSync {
    private StatusSync() {}

    public static void syncAllTo(ServerPlayer viewer) {
        if (viewer.getServer() == null) return;
        for (ServerPlayer subject : viewer.getServer().getPlayerList().getPlayers()) {
            ServerPlayNetworking.send(viewer, payload(subject));
        }
    }

    public static void broadcast(ServerPlayer subject) {
        if (subject.getServer() == null) return;
        PlayerStatusPayload payload = payload(subject);
        for (ServerPlayer viewer : subject.getServer().getPlayerList().getPlayers()) {
            ServerPlayNetworking.send(viewer, payload);
        }
    }

    public static void removeFromClients(net.minecraft.server.MinecraftServer server, int entityId) {
        if (server == null) return;
        PlayerStatusPayload payload = new PlayerStatusPayload(entityId, -1, 0, 0, "0,0,0,0,0,0");
        for (ServerPlayer viewer : server.getPlayerList().getPlayers()) {
            ServerPlayNetworking.send(viewer, payload);
        }
    }

    private static PlayerStatusPayload payload(ServerPlayer player) {
        PlayerData data = HeavenHell.DATA.get(player.getUUID());
        StringBuilder cooldowns = new StringBuilder();
        for (int slot = 0; slot < 6; slot++) {
            if (slot > 0) cooldowns.append(',');
            cooldowns.append(ActiveAbilityService.cooldownRemainingSeconds(data, slot));
        }
        return new PlayerStatusPayload(player.getId(), data.race.ordinal(), data.rank().ordinal(), data.karma, cooldowns.toString());
    }
}
