package com.kuku.heavenhell.network;

import com.kuku.heavenhell.HeavenHell;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server-to-client visual/status snapshot. -1 race means remove the entity from the client cache. */
public record PlayerStatusPayload(int entityId, int raceId, int rankId, int karma, String cooldowns) implements CustomPacketPayload {
    public static final Type<PlayerStatusPayload> TYPE = new Type<>(
            Identifier.fromNamespaceAndPath(HeavenHell.MOD_ID, "player_status"));
    public static final StreamCodec<RegistryFriendlyByteBuf, PlayerStatusPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, PlayerStatusPayload::entityId,
            ByteBufCodecs.VAR_INT, PlayerStatusPayload::raceId,
            ByteBufCodecs.VAR_INT, PlayerStatusPayload::rankId,
            ByteBufCodecs.VAR_INT, PlayerStatusPayload::karma,
            ByteBufCodecs.STRING_UTF8, PlayerStatusPayload::cooldowns,
            PlayerStatusPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
