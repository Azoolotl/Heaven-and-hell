package com.kuku.heavenhell.client.render;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.client.PlayerStatusCache;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import com.mojang.blaze3d.vertex.PoseStack;

/** Client-only cosmetics, driven solely by the server's synced race/rank snapshot. */
public final class RaceWingsLayer extends RenderLayer<AvatarRenderState, PlayerModel> {
    private static final Identifier ANGEL_TEXTURE = Identifier.fromNamespaceAndPath(
            HeavenHell.MOD_ID, "textures/entity/angel_wings.png");
    private static final Identifier DEMON_TEXTURE = Identifier.fromNamespaceAndPath(
            HeavenHell.MOD_ID, "textures/entity/demon_wings.png");

    private final RaceWingsModel model;

    public RaceWingsLayer(RenderLayerParent<AvatarRenderState, PlayerModel> parent, ModelPart bakedRoot) {
        super(parent);
        this.model = new RaceWingsModel(bakedRoot);
    }

    @Override
    public void submit(PoseStack matrices, SubmitNodeCollector queue, int packedLight,
                       AvatarRenderState state, float limbAngle, float limbDistance) {
        PlayerStatusCache.Status status = PlayerStatusCache.get(state.id);
        if (status == null || !status.isPowered() || state.isInvisible || state.isSpectator) return;
        model.configure(status.raceId(), status.rankId());
        model.setupAnim(state);
        matrices.pushPose();
        // The model is centered on the player model origin; a slight rear offset keeps it clear of armor.
        matrices.translate(0.0, 0.0, 0.12);
        Identifier texture = status.isAngel() ? ANGEL_TEXTURE : DEMON_TEXTURE;
        int tint = status.isAngel() ? 0xFFFFFFFF : 0xFFFFFFFF;
        renderColoredCutoutModel(model, texture, matrices, queue, packedLight, state, tint, OverlayTexture.NO_OVERLAY);
        matrices.popPose();
    }
}
