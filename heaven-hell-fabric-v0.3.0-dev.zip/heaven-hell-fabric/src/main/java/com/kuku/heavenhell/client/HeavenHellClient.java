package com.kuku.heavenhell.client;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.network.ActivateAbilityPayload;
import com.kuku.heavenhell.network.PlayerStatusPayload;
import com.kuku.heavenhell.client.render.RaceWingsLayer;
import com.kuku.heavenhell.client.render.RaceWingsModel;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.resources.Identifier;

/** Six ability bindings plus a local progression screen shortcut. */
public final class HeavenHellClient implements ClientModInitializer {
    private static final ModelLayerLocation RACE_WINGS_LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(HeavenHell.MOD_ID, "race_wings"), "main");

    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath(HeavenHell.MOD_ID, "abilities"));

    private static KeyMapping key(String path, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.heavenhell." + path, InputConstants.Type.KEYSYM, key, CATEGORY));
    }

    private static final KeyMapping HOLY_BURST = key("holy_burst", InputConstants.KEY_G);
    private static final KeyMapping DIVINE_JUDGEMENT = key("divine_judgement", InputConstants.KEY_H);
    private static final KeyMapping HEAVENS_WRATH = key("heavens_wrath", InputConstants.KEY_J);
    private static final KeyMapping INFERNAL_BLAST = key("infernal_blast", InputConstants.KEY_Z);
    private static final KeyMapping HELLFIRE_CHAINS = key("hellfire_chains", InputConstants.KEY_X);
    private static final KeyMapping INFERNAL_CATACLYSM = key("infernal_cataclysm", InputConstants.KEY_C);
    private static final KeyMapping OPEN_STATUS = key("open_status", InputConstants.KEY_V);

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(RACE_WINGS_LAYER, RaceWingsModel::createLayer);
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, helper, context) -> {
            if (entityType == EntityType.PLAYER && entityRenderer instanceof AvatarRenderer<?> avatarRenderer) {
                helper.register(new RaceWingsLayer(avatarRenderer, context.getModelSet().bakeLayer(RACE_WINGS_LAYER)));
            }
        });
        ClientPlayNetworking.registerGlobalReceiver(PlayerStatusPayload.TYPE, (payload, context) ->
                context.client().execute(() -> PlayerStatusCache.update(
                        payload.entityId(), payload.raceId(), payload.rankId(), payload.karma(), payload.cooldowns())));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> PlayerStatusCache.clear());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.getConnection() == null) return;
            if (ClientPlayNetworking.canSend(ActivateAbilityPayload.TYPE)) {
                send(HOLY_BURST, 0);
                send(DIVINE_JUDGEMENT, 1);
                send(HEAVENS_WRATH, 2);
                send(INFERNAL_BLAST, 3);
                send(HELLFIRE_CHAINS, 4);
                send(INFERNAL_CATACLYSM, 5);
            }
            while (OPEN_STATUS.consumeClick()) {
                client.setScreen(new RaceStatusScreen());
            }
        });
    }

    private static void send(KeyMapping mapping, int slot) {
        while (mapping.consumeClick()) ClientPlayNetworking.send(new ActivateAbilityPayload(slot));
    }
}
