package com.kuku.heavenhell.network;

import com.kuku.heavenhell.gameplay.ActiveAbilityService;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

/** Registers the one bounded C2S ability request channel. */
public final class AbilityNetworking {
    private AbilityNetworking() {}

    public static void register() {
        PayloadTypeRegistry.playC2S().register(ActivateAbilityPayload.TYPE, ActivateAbilityPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PlayerStatusPayload.TYPE, PlayerStatusPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActivateAbilityPayload.TYPE, (payload, context) -> {
            if (payload.slot() < 0 || payload.slot() > 5) return;
            context.server().execute(() -> ActiveAbilityService.activate(context.player(), payload.slot()));
        });
    }
}
