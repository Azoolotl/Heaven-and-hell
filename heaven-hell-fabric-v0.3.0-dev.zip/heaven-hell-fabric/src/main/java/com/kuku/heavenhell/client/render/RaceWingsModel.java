package com.kuku.heavenhell.client.render;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;

/** Lightweight cosmetic wing/halo/horn model. It never changes player physics or equipment. */
public final class RaceWingsModel extends EntityModel<AvatarRenderState> {
    private final ModelPart leftWing;
    private final ModelPart rightWing;
    private final ModelPart leftWingTwo;
    private final ModelPart rightWingTwo;
    private final ModelPart leftWingThree;
    private final ModelPart rightWingThree;
    private final ModelPart halo;
    private final ModelPart leftHorn;
    private final ModelPart rightHorn;

    public RaceWingsModel(ModelPart root) {
        super(root);
        leftWing = root.getChild("left_wing");
        rightWing = root.getChild("right_wing");
        leftWingTwo = root.getChild("left_wing_two");
        rightWingTwo = root.getChild("right_wing_two");
        leftWingThree = root.getChild("left_wing_three");
        rightWingThree = root.getChild("right_wing_three");
        halo = root.getChild("halo");
        leftHorn = root.getChild("left_horn");
        rightHorn = root.getChild("right_horn");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        CubeDeformation thin = new CubeDeformation(0.025F);

        addWing(root, "left_wing", false, 2.5F, -12.0F, 2.0F, 13.0F, thin);
        addWing(root, "right_wing", true, -2.5F, -12.0F, 2.0F, 13.0F, thin);
        addWing(root, "left_wing_two", false, 2.2F, -11.5F, 2.2F, 10.0F, thin);
        addWing(root, "right_wing_two", true, -2.2F, -11.5F, 2.2F, 10.0F, thin);
        addWing(root, "left_wing_three", false, 2.0F, -11.0F, 2.4F, 14.0F, thin);
        addWing(root, "right_wing_three", true, -2.0F, -11.0F, 2.4F, 14.0F, thin);

        PartDefinition halo = root.addOrReplaceChild("halo", CubeListBuilder.create()
                .texOffs(0, 48).addBox(-4.0F, 0.0F, -1.0F, 8.0F, 1.0F, 1.0F, thin)
                .texOffs(0, 48).addBox(-4.0F, 0.0F, 2.0F, 8.0F, 1.0F, 1.0F, thin)
                .texOffs(0, 52).addBox(-4.0F, 0.0F, -1.0F, 1.0F, 1.0F, 3.0F, thin)
                .texOffs(0, 52).addBox(3.0F, 0.0F, -1.0F, 1.0F, 1.0F, 3.0F, thin),
                PartPose.offset(0.0F, -27.0F, 0.0F));

        root.addOrReplaceChild("left_horn", CubeListBuilder.create().texOffs(32, 48)
                .addBox(-1.0F, -4.0F, -0.5F, 2.0F, 5.0F, 2.0F, thin),
                PartPose.offsetAndRotation(3.0F, -23.0F, 0.0F, 0.0F, 0.0F, 0.28F));
        root.addOrReplaceChild("right_horn", CubeListBuilder.create().texOffs(32, 48)
                .addBox(-1.0F, -4.0F, -0.5F, 2.0F, 5.0F, 2.0F, thin),
                PartPose.offsetAndRotation(-3.0F, -23.0F, 0.0F, 0.0F, 0.0F, -0.28F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    private static void addWing(PartDefinition root, String name, boolean mirror,
                                float x, float y, float z, float length, CubeDeformation deformation) {
        // Mirror the geometry across the player's center line as well as its texture UVs.
        // CubeListBuilder.mirror() alone only mirrors UV orientation, not cube positions.
        float x0 = mirror ? -2.0F : -1.0F;
        float x1 = mirror ? -1.0F : -3.0F;
        float x2 = mirror ?  1.0F : -5.0F;
        float x3 = mirror ?  3.0F : -7.0F;
        CubeListBuilder cubes = CubeListBuilder.create().mirror(mirror)
                .texOffs(0, 0).addBox(x0, -1.0F, 0.0F, 3.0F, 5.0F, 1.0F, deformation)
                .texOffs(12, 0).addBox(x1, 2.0F, 0.0F, 4.0F, length - 2.0F, 1.0F, deformation)
                .texOffs(24, 0).addBox(x2, 4.0F, 0.0F, 4.0F, length - 5.0F, 1.0F, deformation)
                .texOffs(36, 0).addBox(x3, 6.0F, 0.0F, 4.0F, length - 8.0F, 1.0F, deformation);
        root.addOrReplaceChild(name, cubes,
                PartPose.offsetAndRotation(x, y, z, 0.0F, mirror ? 0.08F : -0.08F, mirror ? -0.24F : 0.24F));
    }

    public void configure(int raceId, int rankId) {
        boolean angel = raceId == 1;
        int rank = rankId;
        leftWing.visible = rightWing.visible = rank > 0;
        leftWingTwo.visible = rightWingTwo.visible = angel ? rank >= 2 : rank >= 5;
        leftWingThree.visible = rightWingThree.visible = angel ? rank >= 3 : rank >= 6;
        halo.visible = angel && rank > 0;
        leftHorn.visible = rightHorn.visible = !angel && rank > 0;
    }

    @Override
    public void setupAnim(AvatarRenderState state) {
        root().resetPose();
        float flap = (float) Math.sin(state.ageInTicks * 0.12F) * 0.10F;
        leftWing.zRot = 0.22F + flap;
        rightWing.zRot = -0.22F - flap;
        leftWingTwo.zRot = 0.38F + flap * 0.8F;
        rightWingTwo.zRot = -0.38F - flap * 0.8F;
        leftWingThree.zRot = 0.52F + flap * 0.7F;
        rightWingThree.zRot = -0.52F - flap * 0.7F;
        halo.yRot = state.ageInTicks * 0.025F;
    }
}
