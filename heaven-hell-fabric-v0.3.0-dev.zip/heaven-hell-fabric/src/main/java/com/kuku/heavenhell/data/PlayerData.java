package com.kuku.heavenhell.data;

import com.kuku.heavenhell.HeavenHell;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Persistent per-player progression and anti-farming state. All mutations are server-side. */
public final class PlayerData {
    public final UUID uuid;
    public int karma;
    public Race race = Race.HUMAN;
    public long lastUpdated;

    /** Per-victim PvP reward cooldowns (victim UUID -> epoch millis). */
    public Map<String, Long> playerKillCooldowns = new HashMap<>();
    /** Per-recipient cooldowns for registered help/revival events. */
    public Map<String, Long> helpRewardCooldowns = new HashMap<>();
    /** Per-recipient gift diminishing-return state (recipient UUID -> state). */
    public Map<String, GiftState> giftStates = new HashMap<>();
    /** Daily donor gift karma cap. */
    public long giftRewardDay;
    public int giftKarmaEarnedToday;
    /** Daily cap for positive hostile-mob kill karma. */
    public long mobRewardDay;
    public int mobKarmaEarnedToday;
    /** Divine Blessing interval state, persisted to prevent restart refresh exploits. */
    public long lastDivineBlessingGameTime;
    /** Bloodthirst melee counter and cooldown, measured in overworld game ticks. */
    /** UTC epoch-millis cooldown timestamps keyed by stable ability id. */
    public Map<String, Long> abilityCooldowns = new HashMap<>();
    public int bloodthirstHitCount;
    public long lastBloodthirstProcGameTime;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.lastUpdated = System.currentTimeMillis();
    }

    public Rank rank() {
        HeavenHellConfigView c = HeavenHellConfigView.current();
        return Rank.forState(race, karma, c.angel, c.archangel, c.seraphim, c.demon, c.archdemon, c.demonLord);
    }

    public boolean isPowerless() { return race != Race.HUMAN && rank() == Rank.NONE; }

    public void setKarma(int value) {
        karma = Math.max(-100, Math.min(100, value));
        lastUpdated = System.currentTimeMillis();
        lockRaceIfNeeded();
    }

    public void addKarma(int amount) { setKarma(karma + amount); }

    /** Administrative override. A later karma update will not undo a non-Human race. */
    public void setRace(Race newRace) {
        race = newRace;
        lastUpdated = System.currentTimeMillis();
    }

    public void lockRaceIfNeeded() {
        if (race == Race.HUMAN) {
            if (karma >= HeavenHell.CONFIG.angelThreshold) race = Race.ANGEL;
            else if (karma <= HeavenHell.CONFIG.demonThreshold) race = Race.DEMON;
        }
    }

    public void purify() {
        karma = 0;
        race = Race.HUMAN;
        lastUpdated = System.currentTimeMillis();
        // Keep anti-farming history across purification. Otherwise a rare reset item
        // could be used to bypass PvP, help, gift, or daily mob-reward limits.
        abilityCooldowns.clear();
        bloodthirstHitCount = 0;
        lastBloodthirstProcGameTime = 0;
        lastDivineBlessingGameTime = 0;
    }

    public GiftState giftState(UUID recipient, long epochDay) {
        giftStates.entrySet().removeIf(entry -> entry.getValue() == null || entry.getValue().epochDay < epochDay - 1);
        String key = recipient.toString();
        GiftState state = giftStates.computeIfAbsent(key, ignored -> new GiftState());
        if (state.epochDay != epochDay) {
            state.epochDay = epochDay;
            state.rewardedTransfers = 0;
        }
        return state;
    }

    /** A compact immutable view avoids coupling rank calculation to config internals. */
    private record HeavenHellConfigView(int angel, int archangel, int seraphim,
                                        int demon, int archdemon, int demonLord) {
        static HeavenHellConfigView current() {
            var c = HeavenHell.CONFIG;
            return new HeavenHellConfigView(c.angelThreshold, c.archangelThreshold,
                    c.seraphimThreshold, c.demonThreshold, c.archdemonThreshold, c.demonLordThreshold);
        }
    }

    public static final class GiftState {
        public long epochDay;
        public int rewardedTransfers;
    }
}
