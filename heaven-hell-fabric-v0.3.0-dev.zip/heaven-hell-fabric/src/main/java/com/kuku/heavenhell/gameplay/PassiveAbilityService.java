package com.kuku.heavenhell.gameplay;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.data.PlayerData;
import com.kuku.heavenhell.data.Race;
import com.kuku.heavenhell.data.Rank;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.phys.AABB;

/** Low-frequency, server-side passive processing. No per-entity persistent ticking is installed. */
public final class PassiveAbilityService {
    private static long tickCounter;

    private PassiveAbilityService() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(PassiveAbilityService::onServerTick);
    }

    private static void onServerTick(MinecraftServer server) {
        tickCounter++;
        int interval = Math.max(10, HeavenHell.CONFIG.passivePulseTicks);
        int dreadInterval = Math.max(10, HeavenHell.CONFIG.demonLordDreadPulseTicks);
        boolean passivePulse = tickCounter % interval == 0;
        boolean fearPulse = tickCounter % 40 == 0;
        boolean dreadPulse = tickCounter % dreadInterval == 0;
        if (!passivePulse && !fearPulse && !dreadPulse) return;
        long worldTime = server.overworld().getGameTime();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            tickPlayer(player, worldTime, passivePulse, fearPulse, dreadPulse);
        }
    }

    private static void tickPlayer(ServerPlayer player, long worldTime,
                                   boolean passivePulse, boolean fearPulse, boolean dreadPulse) {
        PlayerData data = HeavenHell.DATA.get(player.getUUID());
        if (data.race == Race.HUMAN || data.isPowerless()) return;
        Rank rank = data.rank();
        ServerLevel level = player.level();

        if (data.race == Race.ANGEL) {
            if (!isAngelRank(rank)) return;
            if (passivePulse && HeavenHell.CONFIG.angelBlessingEnabled && worldTime - data.lastDivineBlessingGameTime
                    >= HeavenHell.CONFIG.angelBlessingIntervalSeconds * 20L) {
                data.lastDivineBlessingGameTime = worldTime;
                player.heal(HeavenHell.CONFIG.angelBlessingHeal);
                // The timestamp is persisted on disconnect/server shutdown; avoid forcing
                // a full-world JSON rewrite on every ten-second passive pulse.
            }
            if (passivePulse && (rank == Rank.ARCHANGEL || rank == Rank.SERAPHIM)
                    && HeavenHell.CONFIG.archangelResistanceEnabled) {
                int amplifier = rank == Rank.SERAPHIM ? 1 : 0;
                applyWithoutDowngrading(player, MobEffects.RESISTANCE, amplifier, 45);
                if (!player.onGround() && player.getDeltaMovement().y < -0.15) {
                    applyWithoutDowngrading(player, MobEffects.SLOW_FALLING, 0, 25);
                }
            }
            if (rank == Rank.SERAPHIM) {
                if (passivePulse && HeavenHell.CONFIG.seraphimPoisonImmunity && player.hasEffect(MobEffects.POISON)) {
                    player.removeEffect(MobEffects.POISON);
                }
                if (fearPulse) frightenHostiles(player, level);
            }
            if (passivePulse && HeavenHell.CONFIG.auraParticlesEnabled) {
                emit(player, ParticleTypes.END_ROD, rank == Rank.SERAPHIM ? 3 : 1);
            }
            if (passivePulse && HeavenHell.CONFIG.netherAngelWeakness && level.dimension() == net.minecraft.world.level.Level.NETHER) {
                applyWithoutDowngrading(player, MobEffects.WEAKNESS, 0, 45);
                applyWithoutDowngrading(player, MobEffects.SLOWNESS, 0, 45);
            }
            return;
        }

        if (data.race == Race.DEMON && isDemonRank(rank)) {
            if (passivePulse && HeavenHell.CONFIG.demonFireResistanceEnabled) {
                applyWithoutDowngrading(player, MobEffects.FIRE_RESISTANCE, 0, 45);
            }
            if (rank == Rank.DEMON_LORD && dreadPulse) applyDreadPresence(player, level);
            if (passivePulse && HeavenHell.CONFIG.auraParticlesEnabled) {
                emit(player, rank == Rank.DEMON_LORD ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME,
                        rank == Rank.DEMON_LORD ? 4 : 2);
                if (rank == Rank.DEMON_LORD) emit(player, ParticleTypes.SMOKE, 1);
            }
            if (passivePulse && HeavenHell.CONFIG.overworldDemonWeakness && level.dimension() == net.minecraft.world.level.Level.OVERWORLD) {
                applyWithoutDowngrading(player, MobEffects.WEAKNESS, 0, 45);
                applyWithoutDowngrading(player, MobEffects.SLOWNESS, 0, 45);
            }
        }
    }

    private static void applyWithoutDowngrading(ServerPlayer player,
            net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect,
            int amplifier, int duration) {
        MobEffectInstance current = player.getEffect(effect);
        if (current == null || current.getAmplifier() < amplifier
                || (current.getAmplifier() == amplifier && current.getDuration() < duration / 2)) {
            player.addEffect(new MobEffectInstance(effect, duration, amplifier, true, false, false));
        }
    }

    private static void frightenHostiles(ServerPlayer player, ServerLevel level) {
        AABB area = player.getBoundingBox().inflate(6.0);
        for (Mob mob : level.getEntitiesOfClass(Mob.class, area,
                m -> m.isAlive() && m.getType().getCategory() == MobCategory.MONSTER && m.getTarget() == player)) {
            if (player.getRandom().nextFloat() < 0.20f) {
                mob.setTarget(null);
                applyWithoutDowngrading(mob, MobEffects.SLOWNESS, 0, 30);
            }
        }
    }

    private static void applyDreadPresence(ServerPlayer player, ServerLevel level) {
        int pulse = Math.max(10, HeavenHell.CONFIG.demonLordDreadPulseTicks);
        double radius = HeavenHell.CONFIG.demonLordDreadRadius;
        double radiusSquared = radius * radius;
        // Dread Presence affects hostile players as well as hostile mobs, but never
        // applies its debuff to scoreboard allies when friendly fire is disabled.
        for (ServerPlayer target : level.players()) {
            if (target == player || player.distanceToSqr(target) > radiusSquared) continue;
            if (!HeavenHell.CONFIG.friendlyFire && player.isAlliedTo(target)) continue;
            applyWithoutDowngrading(target, MobEffects.WEAKNESS, 0, pulse + 10);
        }
        for (Mob mob : level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(radius),
                m -> m.isAlive() && m.getType().getCategory() == MobCategory.MONSTER)) {
            applyWithoutDowngrading(mob, MobEffects.WEAKNESS, 0, pulse + 10);
        }
    }

    private static void applyWithoutDowngrading(Mob mob,
            net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect,
            int amplifier, int duration) {
        MobEffectInstance current = mob.getEffect(effect);
        if (current == null || current.getAmplifier() < amplifier
                || (current.getAmplifier() == amplifier && current.getDuration() < duration / 2)) {
            mob.addEffect(new MobEffectInstance(effect, duration, amplifier, true, false, false));
        }
    }

    private static void emit(ServerPlayer player, ParticleOptions particle, int count) {
        player.level().sendParticles(particle, player.getX(), player.getY() + 1.0, player.getZ(),
                count, 0.28, 0.42, 0.28, 0.005);
    }

    private static boolean isAngelRank(Rank rank) {
        return rank == Rank.LESSER_ANGEL || rank == Rank.ARCHANGEL || rank == Rank.SERAPHIM;
    }

    private static boolean isDemonRank(Rank rank) {
        return rank == Rank.LESSER_DEMON || rank == Rank.ARCHDEMON || rank == Rank.DEMON_LORD;
    }
}
