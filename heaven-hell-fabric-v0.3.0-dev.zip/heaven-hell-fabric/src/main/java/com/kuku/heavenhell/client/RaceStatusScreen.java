package com.kuku.heavenhell.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Compact, read-only progression screen. All displayed progression is fed by the server. */
public final class RaceStatusScreen extends Screen {
    public RaceStatusScreen() {
        super(Component.translatable("screen.heavenhell.status.title"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        int panelWidth = 300;
        int panelHeight = 224;
        int left = (this.width - panelWidth) / 2;
        int top = (this.height - panelHeight) / 2;
        graphics.fill(left, top, left + panelWidth, top + panelHeight, 0xE91A1424);
        graphics.fill(left, top, left + panelWidth, top + 2, 0xFFFFD36A);
        graphics.fill(left, top + panelHeight - 2, left + panelWidth, top + panelHeight, 0xFF8E5BC6);

        graphics.drawCenteredString(this.font, Component.translatable("screen.heavenhell.status.title"), this.width / 2, top + 12, 0xFFFFE4A1);
        graphics.drawCenteredString(this.font, Component.translatable("screen.heavenhell.status.subtitle"), this.width / 2, top + 27, 0xFFBFB4D5);

        Minecraft client = Minecraft.getInstance();
        PlayerStatusCache.Status status = client.player == null ? null
                : PlayerStatusCache.get(client.player.getId());
        int y = top + 52;
        if (status == null) {
            graphics.drawCenteredString(this.font, Component.translatable("screen.heavenhell.status.syncing"), this.width / 2, y + 28, 0xFFFFFFFF);
        } else {
            String race = switch (status.raceId()) {
                case 1 -> Component.translatable("screen.heavenhell.status.race.angel").getString();
                case 2 -> Component.translatable("screen.heavenhell.status.race.demon").getString();
                default -> Component.translatable("screen.heavenhell.status.race.human").getString();
            };
            String rank = switch (status.rankId()) {
                case 1 -> "Lesser Angel";
                case 2 -> "Archangel";
                case 3 -> "Seraphim";
                case 4 -> "Lesser Demon";
                case 5 -> "Archdemon";
                case 6 -> "Demon Lord";
                default -> Component.translatable(status.raceId() == 0
                        ? "screen.heavenhell.status.rank.unawakened"
                        : "screen.heavenhell.status.rank.powerless").getString();
            };
            int color = status.raceId() == 1 ? 0xFFFFD86E : status.raceId() == 2 ? 0xFFFF6262 : 0xFFE6E6E6;
            graphics.drawCenteredString(this.font, race, this.width / 2, y, color);
            graphics.drawCenteredString(this.font, rank, this.width / 2, y + 17, 0xFFFFFFFF);
            graphics.drawCenteredString(this.font, Component.translatable("screen.heavenhell.status.karma",
                    (status.karma() > 0 ? "+" : "") + status.karma()),
                    this.width / 2, y + 35, status.karma() >= 0 ? 0xFFFFD88B : 0xFFFF8585);

            int dividerY = y + 58;
            graphics.fill(left + 24, dividerY, left + panelWidth - 24, dividerY + 1, 0xFF675B78);
            graphics.drawString(this.font, Component.translatable("screen.heavenhell.status.unlocked"), left + 24, dividerY + 10, 0xFFD9C9F0);
            String[] abilities = unlockedAbilities(status.raceId(), status.rankId());
            int lineY = dividerY + 25;
            if (abilities.length == 0) {
                graphics.drawString(this.font, Component.translatable("screen.heavenhell.status.no_abilities"),
                        left + 24, lineY, 0xFFB6ADBF);
            } else {
                int slot = firstSlot(status.raceId());
                for (int i = 0; i < abilities.length; i++) {
                    int abilitySlot = slot + (i >= passiveCount(status.rankId(), status.raceId())
                            ? i - passiveCount(status.rankId(), status.raceId()) : -1);
                    String cooldown = i < passiveCount(status.rankId(), status.raceId())
                            ? Component.translatable("screen.heavenhell.status.passive").getString()
                            : status.cooldownSeconds(abilitySlot) > 0
                                ? Component.translatable("screen.heavenhell.status.recharging", status.cooldownSeconds(abilitySlot)).getString()
                                : Component.translatable("screen.heavenhell.status.ready").getString();
                    graphics.drawString(this.font, "• " + abilities[i], left + 24, lineY, 0xFFFFFFFF);
                    graphics.drawString(this.font, cooldown, left + panelWidth - 91, lineY, 0xFFBFB4D5);
                    lineY += 13;
                }
            }
        }
        graphics.drawCenteredString(this.font, Component.translatable("screen.heavenhell.status.close"), this.width / 2, top + panelHeight - 16, 0xFFB7AFC2);
        super.render(graphics, mouseX, mouseY, delta);
    }


    private static int firstSlot(int race) { return race == 1 ? 0 : 3; }

    private static int passiveCount(int rank, int race) {
        if (race == 1) return switch (rank) { case 1 -> 1; case 2 -> 2; case 3 -> 3; default -> 0; };
        if (race == 2) return switch (rank) { case 4 -> 1; case 5 -> 2; case 6 -> 3; default -> 0; };
        return 0;
    }

    private static String[] unlockedAbilities(int race, int rank) {
        if (race == 1) {
            return switch (rank) {
                case 1 -> new String[]{"Divine Blessing", "Holy Burst"};
                case 2 -> new String[]{"Divine Blessing", "Celestial Grace", "Holy Burst", "Divine Judgement"};
                case 3 -> new String[]{"Divine Blessing", "Celestial Grace", "Divine Authority", "Holy Burst", "Divine Judgement", "Heaven's Wrath"};
                default -> new String[0];
            };
        }
        if (race == 2) {
            return switch (rank) {
                case 4 -> new String[]{"Emberborn", "Infernal Blast"};
                case 5 -> new String[]{"Emberborn", "Bloodthirst", "Infernal Blast", "Hellfire Chains"};
                case 6 -> new String[]{"Emberborn", "Bloodthirst", "Dread Presence", "Infernal Blast", "Hellfire Chains", "Infernal Cataclysm"};
                default -> new String[0];
            };
        }
        return new String[0];
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
